from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)

# Configuração da chave secreta para usar sessões
app.secret_key = 'sua_chave_secreta_aqui'

# Dados fictícios para simular o login
USUARIOS = {
    'admin': '1234',
}

# Simulando um banco de dados de projetos
projetos = []

# Dados fictícios para simular os participantes
participantes_db = []

# Rota para a página inicial (index)
@app.route('/')
def index():
    return render_template('index.html')

# Rota para página de login facilitador
@app.route('/login-facilitador', methods=['GET', 'POST'])
def login_facilitador():
    if request.method == 'POST':
        usuario = request.form['usuario']
        senha = request.form['senha']
        if usuario in USUARIOS and USUARIOS[usuario] == senha:
            session['usuario'] = usuario
            return redirect(url_for('painel_facilitador'))
        else:
            erro = "Usuário ou senha inválidos!"
            return render_template('facilitador/login_facilitador.html', erro=erro)
    return render_template('facilitador/login_facilitador.html')

# Rota para o painel do facilitador
@app.route('/painel-facilitador')
def painel_facilitador():
    if 'usuario' not in session:
        return redirect(url_for('login_facilitador'))
    return render_template('facilitador/painel_facilitador.html')

# Rota para novo projeto
@app.route('/novo-projeto', methods=['GET', 'POST'])
def novo_projeto():
    if 'usuario' not in session:
        return redirect(url_for('login_facilitador'))
    if request.method == 'POST':
        nome = request.form['nome']
        descricao = request.form['descricao']
        data_inicio = request.form['data_inicio']
        data_fim = request.form['data_fim']
        projeto = {'nome': nome, 'descricao': descricao, 'data_inicio': data_inicio, 'data_fim': data_fim}
        projetos.append(projeto)
        return redirect(url_for('projetos_criados'))
    return render_template('facilitador/inicio/novo_projeto.html')

# Rota para projetos criados
@app.route('/projetos-criados')
def projetos_criados():
    if 'usuario' not in session:
        return redirect(url_for('login_facilitador'))
    return render_template('facilitador/inicio/projetos_criados.html', projetos=projetos)

# Rota principal para gerenciar participantes
@app.route('/gerenciar-participantes', methods=['GET', 'POST'])
def gerenciar_participantes():
    if request.method == 'POST':
        # Verifica se os campos essenciais estão presentes no formulário
        try:
            nome = request.form['nome']
            matricula = request.form['matricula']
            supervisor = request.form['supervisor']
            
            # Campos adicionais (caso existam)
            data_treinamento = request.form.get('data_treinamento', '')  # Caso não enviado, ficará vazio
            projeto = request.form.get('projeto', '')  # Caso não enviado, ficará vazio
            nota = request.form.get('nota', '')  # Caso não enviado, ficará vazio

            # Cria um novo dicionário para o participante
            participante = {
                'nome': nome.title(),  # Primeira letra de cada palavra em maiúscula
                'matricula': matricula,
                'supervisor': supervisor,
                'data_treinamento': data_treinamento,  # Adiciona data de treinamento
                'projeto': projeto,  # Adiciona projeto
                'nota': nota  # Adiciona nota
            }

            # Adiciona o participante à lista
            participantes_db.append(participante)

            # Redireciona de volta à página de gerenciamento
            return redirect(url_for('gerenciar_participantes'))
        except Exception as e:
            print(f"Erro ao adicionar participante: {e}")
            return "Ocorreu um erro ao adicionar o participante, tente novamente.", 400

    # Renderiza a página com os participantes
    return render_template('facilitador/gerenciar/gerenciar_participantes.html', participantes=participantes_db)

@app.route('/configuracoes')
def configuracoes():
    return render_template('facilitador/configuracoes/configuracoes.html')

# Rota para logout
@app.route('/logout')
def logout():
    session.pop('usuario', None)  # Remove o usuário da sessão
    return redirect(url_for('index'))  # Redireciona para a página principal (index)

# Rota para página de login participante
@app.route('/login-participante', methods=['GET', 'POST'])
def login_participante():
    if request.method == 'POST':
        nome = request.form['nome'].strip().title()
        matricula = request.form['matricula'].strip()

        for p in participantes_db:
            if p['nome'] == nome and p['matricula'] == matricula:
                session['participante'] = {'nome': nome, 'matricula': matricula}
                return redirect(url_for('painel_participante'))

        erro = "Nome ou matrícula inválidos!"
        return render_template('participante/login_participante.html', erro=erro)

    return render_template('participante/login_participante.html')

# Rota para o painel do participante
@app.route('/painel-participante')
def painel_participante():
    if 'participante' not in session:
        return redirect(url_for('login_participante'))
    
    participante = session['participante']
    return render_template('participante/painel_participante.html', participante=participante)

from flask import jsonify

@app.route('/eventos-participante')
def eventos_participante():
    if 'participante' not in session:
        return jsonify([]), 401

    participante = session['participante']
    nome = participante['nome']

    eventos = []
    for p in participantes_db:
        if p['nome'] == nome and p.get('projeto'):
            eventos.append({
                "title": p['projeto'],
                "start": p.get('data_treinamento', '2025-05-30'),
                "color": "#2ecc71"
            })
    return jsonify(eventos)


if __name__ == "__main__":
    app.run(debug=True)
