document.addEventListener('DOMContentLoaded', function () {
  const calendarEl = document.getElementById('calendario');

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    locale: 'pt-br',
    height: 'auto',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,dayGridWeek'
    },
    events: [
      {
        title: "Projeto Alpha",
        start: "2025-05-21",
        color: "#2ecc71"
      }
    ],
    dayCellDidMount: function (info) {
      const hoje = new Date();
      const data = info.date;
      if (
        data.getDate() === hoje.getDate() &&
        data.getMonth() === hoje.getMonth() &&
        data.getFullYear() === hoje.getFullYear()
      ) {
        info.el.style.border = '2px solid #2ecc71';
        info.el.style.borderRadius = '50%';
      }
    }
  });

  calendar.render();
});
