document.addEventListener("DOMContentLoaded", function() {
    // Carregar configurações salvas no localStorage, se houver
    if (localStorage.getItem('fundo-cor-header')) {
        document.documentElement.style.setProperty('--cor-fundo-header', localStorage.getItem('fundo-cor-header'));
        document.getElementById('fundo-cor').value = localStorage.getItem('fundo-cor-header');
    }
    if (localStorage.getItem('texto-cor-header')) {
        document.documentElement.style.setProperty('--cor-texto-header', localStorage.getItem('texto-cor-header'));
        document.getElementById('texto-cor').value = localStorage.getItem('texto-cor-header');
    }
    if (localStorage.getItem('fundo-cor-painel')) {
        document.documentElement.style.setProperty('--cor-fundo-painel', localStorage.getItem('fundo-cor-painel'));
        document.getElementById('fundo-painel-cor').value = localStorage.getItem('fundo-cor-painel');
    }
    if (localStorage.getItem('botao-cor')) {
        document.documentElement.style.setProperty('--cor-fundo-botao', localStorage.getItem('botao-cor'));
        document.getElementById('botao-cor').value = localStorage.getItem('botao-cor');
    }
    if (localStorage.getItem('texto-botao-cor')) {
        document.documentElement.style.setProperty('--cor-texto-botao', localStorage.getItem('texto-botao-cor'));
        document.getElementById('texto-botao-cor').value = localStorage.getItem('texto-botao-cor');
    }

    // Manipula o formulário de configurações
    document.getElementById('form-configuracoes').addEventListener('submit', function(event) {
        event.preventDefault(); // Evita o envio do formulário

        // Pega as cores selecionadas
        const corFundoHeader = document.getElementById('fundo-cor').value;
        const corTextoHeader = document.getElementById('texto-cor').value;
        const corFundoPainel = document.getElementById('fundo-painel-cor').value;
        const corBotao = document.getElementById('botao-cor').value;
        const corTextoBotao = document.getElementById('texto-botao-cor').value;

        // Aplica as novas cores nas variáveis CSS
        document.documentElement.style.setProperty('--cor-fundo-header', corFundoHeader);
        document.documentElement.style.setProperty('--cor-texto-header', corTextoHeader);
        document.documentElement.style.setProperty('--cor-fundo-painel', corFundoPainel);
        document.documentElement.style.setProperty('--cor-fundo-botao', corBotao);
        document.documentElement.style.setProperty('--cor-texto-botao', corTextoBotao);

        // Salva as cores no localStorage para persistência
        localStorage.setItem('fundo-cor-header', corFundoHeader);
        localStorage.setItem('texto-cor-header', corTextoHeader);
        localStorage.setItem('fundo-cor-painel', corFundoPainel);
        localStorage.setItem('botao-cor', corBotao);
        localStorage.setItem('texto-botao-cor', corTextoBotao);

        alert("Configurações salvas!");
    });

    document.getElementById('btn-resetar').addEventListener('click', function (e) {
        e.preventDefault(); // evita que o formulário recarregue a página

        // Limpa o localStorage
        localStorage.removeItem('fundo-cor-header');
        localStorage.removeItem('texto-cor-header');
        localStorage.removeItem('fundo-cor-painel');
        localStorage.removeItem('botao-cor');
        localStorage.removeItem('texto-botao-cor');

        // Define as cores padrão
        const padrao = {
            fundoHeader: '#007bff',
            textoHeader: '#ffffff',
            fundoPainel: '#f8f9fa',
            fundoBotao: '#007bff',
            textoBotao: '#ffffff'
        };

        // Aplica no CSS
        document.documentElement.style.setProperty('--cor-fundo-header', padrao.fundoHeader);
        document.documentElement.style.setProperty('--cor-texto-header', padrao.textoHeader);
        document.documentElement.style.setProperty('--cor-fundo-painel', padrao.fundoPainel);
        document.documentElement.style.setProperty('--cor-fundo-botao', padrao.fundoBotao);
        document.documentElement.style.setProperty('--cor-texto-botao', padrao.textoBotao);

        // Atualiza os inputs de cor
        document.getElementById('fundo-cor').value = padrao.fundoHeader;
        document.getElementById('texto-cor').value = padrao.textoHeader;
        document.getElementById('fundo-painel-cor').value = padrao.fundoPainel;
        document.getElementById('botao-cor').value = padrao.fundoBotao;
        document.getElementById('texto-botao-cor').value = padrao.textoBotao;

        alert("Cores restauradas para o padrão!");
    });

    // Botões para alterar as cores
    document.getElementById('btn-cor-default').addEventListener('click', () => {
        // Definir cores padrão
        document.documentElement.style.setProperty('--cor-fundo-header', '#007bff');
        document.documentElement.style.setProperty('--cor-texto-header', 'white');
        document.documentElement.style.setProperty('--cor-fundo-painel', '#f8f9fa');
        document.documentElement.style.setProperty('--cor-fundo-botao', '#007bff');
        document.documentElement.style.setProperty('--cor-texto-botao', 'white');
    });

    document.getElementById('btn-cor-alternativa').addEventListener('click', () => {
        // Definir cores alternativas
        document.documentElement.style.setProperty('--cor-fundo-header', '#ff5733');
        document.documentElement.style.setProperty('--cor-texto-header', 'black');
        document.documentElement.style.setProperty('--cor-fundo-painel', '#f8f9fa');
        document.documentElement.style.setProperty('--cor-fundo-botao', '#c70039');
        document.documentElement.style.setProperty('--cor-texto-botao', 'white');
    });

    document.getElementById('btn-cor-rosa').addEventListener('click', () => {
        // Definir cores claras
        document.documentElement.style.setProperty('--cor-fundo-header', '#ff0080');
        document.documentElement.style.setProperty('--cor-texto-header', 'black');
        document.documentElement.style.setProperty('--cor-fundo-painel', 'white');
        document.documentElement.style.setProperty('--cor-fundo-botao', '#ff0080');
        document.documentElement.style.setProperty('--cor-texto-botao', 'black');
    });
});