// Estado local
let elementosCanvas = [];
let paginaAtual = 0;
let paginas = [[]]; // Cada página contém seus elementos

const canvas = document.getElementById('canvas');

// Adiciona elemento (imagem, vídeo, áudio ou widget) ao canvas
export function adicionarElementoCustomizado(tipo, src, x = 50, y = 50) {
    const wrapper = document.createElement('div');
    wrapper.classList.add('resizable-wrapper');
    wrapper.setAttribute('data-src', src);
    wrapper.setAttribute('data-tipo', tipo);
    wrapper.style.position = 'absolute';
    wrapper.style.left = `${x}px`;
    wrapper.style.top = `${y}px`;

    let element;

    if (tipo === 'img' || tipo === 'video') {
        element = document.createElement(tipo);
        element.src = src;
        element.classList.add('canvas-elemento');
        element.controls = tipo === 'video';
        element.style.width = '100%';
        element.style.height = '100%';
        wrapper.appendChild(element);
    } else if (tipo === 'audio') {
        element = document.createElement('audio');
        element.src = src;
        element.classList.add('canvas-elemento');
        element.controls = true;
        element.style.width = '100%';

        // Define dimensões mínimas para o wrapper de áudio
        wrapper.style.width = '200px';     // ou qualquer largura adequada
        wrapper.style.height = '40px';     // altura mínima para controles de áudio visíveis

        wrapper.appendChild(element);
    } else if (tipo === 'widget') {
    let dados;
    try {
        dados = JSON.parse(src);
    } catch (e) {
        console.warn('Não é JSON de widget válido:', src);
        return;
    }

    element = document.createElement('div');
    element.classList.add('canvas-elemento');
    element.innerHTML = `<p><strong>${dados.enunciado}</strong></p>`;

    if (dados.tipo === 'multipla' || dados.tipo === 'vf') {
        element.innerHTML += dados.opcoes.map((opt, i) => `
            <label>
                <input type="${dados.tipo === 'multipla' ? 'radio' : 'radio'}" name="resposta-${Date.now()}" />
                ${opt.texto}
            </label><br/>
        `).join('');
    } else if (dados.tipo === 'relacione') {
        element.innerHTML += dados.opcoes.map(opt => `
            <div style="margin: 5px 0;">
                <input type="text" value="${opt.texto}" disabled style="width: 100%;" />
            </div>
        `).join('');
    } else if (dados.tipo === 'likert') {
        element.innerHTML += dados.opcoes.map((opt, i) => `
            <label>
                <input type="radio" name="likert-${Date.now()}" />
                ${opt.texto}
            </label><br/>
        `).join('');
    }

    wrapper.appendChild(element);
}


    // Adiciona ao canvas
    canvas.appendChild(wrapper);
    elementosCanvas.push(wrapper);
    paginas[paginaAtual].push(wrapper);

    // Torna interativo
    habilitarMovimento(wrapper);
    habilitarRedimensionamento(wrapper);
}

// Torna elementos movíveis dentro do canvas
function habilitarMovimento(wrapper) {
    let isDragging = false;
    let offsetX, offsetY;

    wrapper.addEventListener('mousedown', (e) => {
        if (e.target.tagName.toLowerCase() === 'button') return; // Evita mover ao clicar em botões
        isDragging = true;
        offsetX = e.offsetX;
        offsetY = e.offsetY;
        wrapper.style.zIndex = 1000;
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const canvasRect = canvas.getBoundingClientRect();
        const x = e.clientX - canvasRect.left - offsetX;
        const y = e.clientY - canvasRect.top - offsetY;

        wrapper.style.left = `${Math.max(0, Math.min(x, canvas.clientWidth - wrapper.offsetWidth))}px`;
        wrapper.style.top = `${Math.max(0, Math.min(y, canvas.clientHeight - wrapper.offsetHeight))}px`;
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        wrapper.style.zIndex = '';
    });
}

// Torna elementos redimensionáveis
function habilitarRedimensionamento(wrapper) {
    const direcoes = ['n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw'];
    direcoes.forEach(dir => {
        const handle = document.createElement('div');
        handle.classList.add('resize-handle', dir);
        wrapper.appendChild(handle);

        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();

            const startX = e.clientX;
            const startY = e.clientY;
            const startWidth = wrapper.offsetWidth;
            const startHeight = wrapper.offsetHeight;
            const startTop = wrapper.offsetTop;
            const startLeft = wrapper.offsetLeft;

            function doDrag(e) {
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;

                if (dir.includes('e')) wrapper.style.width = `${startWidth + dx}px`;
                if (dir.includes('s')) wrapper.style.height = `${startHeight + dy}px`;
                if (dir.includes('w')) {
                    wrapper.style.width = `${startWidth - dx}px`;
                    wrapper.style.left = `${startLeft + dx}px`;
                }
                if (dir.includes('n')) {
                    wrapper.style.height = `${startHeight - dy}px`;
                    wrapper.style.top = `${startTop + dy}px`;
                }
            }

            function stopDrag() {
                document.removeEventListener('mousemove', doDrag);
                document.removeEventListener('mouseup', stopDrag);
            }

            document.addEventListener('mousemove', doDrag);
            document.addEventListener('mouseup', stopDrag);
        });
    });
    
    // Botão de remover
    const btnRemover = document.createElement('button');
    btnRemover.innerText = '✖';
    btnRemover.classList.add('btn-remove-canvas');
    btnRemover.addEventListener('click', () => wrapper.remove());
    wrapper.appendChild(btnRemover);
}


// Muda a página atual do canvas
export function mudarPagina(index) {
    if (!paginas[index]) paginas[index] = [];

    canvas.innerHTML = '';
    paginas[index].forEach(el => canvas.appendChild(el));
    paginaAtual = index;
}

export function removerPagina(index) {
    if (!paginas[index]) return;

    // 1. Remove todos os elementos DOM da página a ser excluída
    paginas[index].forEach(el => {
        if (el && el.parentElement) {
            el.parentElement.removeChild(el);
        }
    });

    // 2. Remove a página do array de páginas
    paginas.splice(index, 1);

    // 3. Ajusta a página atual
    if (paginaAtual === index) {
        paginaAtual = Math.max(0, index - 1);
    } else if (paginaAtual > index) {
        paginaAtual--;
    }

    // 4. Reexibe a página atual (se houver)
    if (paginas.length > 0) {
        mudarPagina(paginaAtual);
    } else {
        // Se todas as páginas foram removidas, inicia com uma nova vazia
        paginas = [[]];
        paginaAtual = 0;
        mudarPagina(0);
    }
}

// Drag & Drop do canvas
canvas.addEventListener('dragover', (e) => e.preventDefault());

canvas.addEventListener('drop', (e) => {
    e.preventDefault();

    const src = e.dataTransfer.getData('text/plain');
    const tipo = e.dataTransfer.getData('tipo');

    if (!src || !tipo) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    adicionarElementoCustomizado(tipo, src, x, y);
});
