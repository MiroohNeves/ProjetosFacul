import { adicionarElementoCustomizado } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const miniaturasContainer = document.getElementById('miniaturas-widgets');
    const buttonObjetiva = document.querySelector('[data-widget="Button_Objetiva"]');

    buttonObjetiva.addEventListener('click', () => abrirModalObjetiva());
});

function abrirModalObjetiva() {
    const overlay = document.createElement('div');
    overlay.className = 'mini-janela-modal';
    overlay.innerHTML = `
        <div class="mini-janela-conteudo">
            <span class="fechar-mini-janela">✖</span>
            <h3>Criar Pergunta Objetiva</h3>

            <label for="tipo-pergunta">Tipo:</label>
            <select id="tipo-pergunta" style="width: 100%; margin-bottom: 10px;">
                <option value="">Selecione um tipo</option>
                <option value="multipla">Múltipla Escolha</option>
                <option value="vf">Verdadeiro/Falso</option>
                <option value="relacione">Relacione as Colunas</option>
                <option value="likert">Escala Likert</option>
            </select>

            <label>Enunciado:</label>
            <textarea id="enunciado" rows="3" style="width: 100%;"></textarea>

            <div id="opcoes-container" class="vf-opcoes-container" style="margin-top: 15px;"></div>

            <button id="salvar-pergunta">Salvar</button>
        </div>
    `;
    document.body.appendChild(overlay);

    const tipoSelect = overlay.querySelector('#tipo-pergunta');
    const opcoesContainer = overlay.querySelector('#opcoes-container');

    tipoSelect.addEventListener('change', () => atualizarCamposPorTipo(tipoSelect.value, opcoesContainer));
    overlay.querySelector('.fechar-mini-janela').addEventListener('click', () => overlay.remove());

    overlay.querySelector('#salvar-pergunta').addEventListener('click', () => {
        const tipo = tipoSelect.value;
        const enunciado = overlay.querySelector('#enunciado').value.trim();

        if (!tipo || !enunciado) {
            alert('Preencha o enunciado e selecione o tipo da pergunta.');
            return;
        }

        const dadosPergunta = {
            tipo,
            enunciado,
            opcoes: [],
        };

        const linhas = opcoesContainer.querySelectorAll('.linha-opcao');
        for (let linha of linhas) {
            const texto = linha.querySelector('.texto-opcao')?.value;
            const nota = parseFloat(linha.querySelector('.input-nota')?.value || 0);
            const correta = linha.querySelector('input[type="radio"], input[type="checkbox"]')?.checked || false;

            if (!texto) {
                alert('Todas as opções devem ser preenchidas.');
                return;
            }

            dadosPergunta.opcoes.push({ texto, nota, correta });
        }

        adicionarMiniaturaWidget(dadosPergunta);
        overlay.remove();
    });
}

function atualizarCamposPorTipo(tipo, container) {
    container.innerHTML = '';

    if (tipo === 'multipla') {
        for (let i = 0; i < 4; i++) {
            container.innerHTML += `
                <div class="linha-opcao">
                    <input type="radio" name="correta" />
                    <input type="text" class="texto-opcao" placeholder="Alternativa ${String.fromCharCode(65 + i)}" />
                    <input type="number" class="input-nota" placeholder="Nota" min="0" />
                </div>
            `;
        }
    }

    if (tipo === 'vf') {
        ['Verdadeiro', 'Falso'].forEach((opcao, i) => {
            container.innerHTML += `
                <div class="linha-opcao">
                    <input type="radio" name="correta" ${i === 0 ? 'checked' : ''} />
                    <input type="text" class="texto-opcao" value="${opcao}" disabled />
                    <input type="number" class="input-nota" placeholder="Nota" min="0" />
                </div>
            `;
        });
    }

    if (tipo === 'relacione') {
        for (let i = 0; i < 3; i++) {
            container.innerHTML += `
                <div class="linha-opcao">
                    <input type="text" class="texto-opcao" placeholder="Item A ↔ Item B" />
                    <input type="number" class="input-nota" placeholder="Nota" min="0" />
                </div>
            `;
        }
    }

    if (tipo === 'likert') {
        ['Discordo Totalmente', 'Discordo', 'Neutro', 'Concordo', 'Concordo Totalmente'].forEach((texto, i) => {
            container.innerHTML += `
                <div class="linha-opcao">
                    <input type="text" class="texto-opcao" value="${texto}" />
                    <input type="number" class="input-nota" value="${i}" />
                </div>
            `;
        });
    }
}

function adicionarMiniaturaWidget(dadosPergunta) {
    const miniaturasContainer = document.getElementById('miniaturas-widgets');

    const wrapper = document.createElement('div');
    wrapper.className = 'botao-widget';
    wrapper.setAttribute('draggable', true);
    wrapper.dataset.widgetData = JSON.stringify(dadosPergunta);

    wrapper.innerHTML = `
        <span>📄 ${dadosPergunta.tipo} - Objetiva</span>
        <button class="btn-apagar">🗑️</button>
    `;

    wrapper.querySelector('.btn-apagar').addEventListener('click', () => wrapper.remove());

    wrapper.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', JSON.stringify(dadosPergunta));
        e.dataTransfer.setData('tipo', 'widget');
    });

    wrapper.addEventListener('dblclick', () => {
        adicionarElementoCustomizado('widget', JSON.stringify(dadosPergunta), 100, 100);
    });

    miniaturasContainer.appendChild(wrapper);
}
