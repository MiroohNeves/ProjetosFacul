document.addEventListener("DOMContentLoaded", () => {
    const Logica = document.querySelector('button[data-widget="Button_Logica"]');
    const Objetiva = document.querySelector('button[data-widget="Button_Objetiva"]');
    const Dissertativa = document.querySelector('button[data-widget="Button_Dissertativa"]');


    if (Logica) {
        Logica.addEventListener("click", () => {
            abrirMiniJanelaLogica(); // função futura
        });
    }
    if (Objetiva) {
        Objetiva.addEventListener("click", () => {
            abrirMiniJanelaObjetiva();
        });
    }
    if (Dissertativa) {
        Dissertativa.addEventListener("click", () => {
            abrirMiniJanelaDissertativa();
        });
    }
});

function abrirMiniJanelaLogica() {
    alert("Mini janela de Lógica (em breve)");
}

function abrirMiniJanelaObjetiva() {
    // Criar o container da mini janela
    const modal = document.createElement("div");
    modal.className = "mini-janela-modal";

    const conteudo = document.createElement("div");
    conteudo.className = "mini-janela-conteudo";

    // Botão de fechar
    const fecharBtn = document.createElement("span");
    fecharBtn.className = "fechar-mini-janela";
    fecharBtn.innerHTML = "&times;";
    fecharBtn.addEventListener("click", () => modal.remove());

    // Dropdown de tipos de questão
    const titulo = document.createElement("h3");
    titulo.textContent = "Escolha o tipo de questão:";

    const select = document.createElement("select");
    select.id = "tipo-questao-select";
    const opcoes = [
        "", // opção em branco
        "Múltipla Escolha",
        "Verdadeiro/Falso",
        "Relacione as Colunas",
        "Escala Likert",
        "Texto"
    ];

    // Adiciona opções ao select
    opcoes.forEach(tipo => {
        const option = document.createElement("option");
        option.value = tipo
            ? tipo
                .normalize("NFD")           // remove acentos
                .replace(/[\u0300-\u036f]/g, "")
                .toLowerCase()
                .replace(/ /g, "-")
            : "";
        option.textContent = tipo || "-- Selecione um tipo --";
        select.appendChild(option);
    });


    // Área onde será exibido o formulário correspondente
    const configuracaoArea = document.createElement("div");
    configuracaoArea.id = "configuracao-widget";

    // Reage ao tipo escolhido e renderiza a interface apropriada
    select.addEventListener("change", (e) => {
        renderizarFormularioTipo(e.target.value, configuracaoArea);
    });

    // Montar estrutura
    conteudo.appendChild(fecharBtn);
    conteudo.appendChild(titulo);
    conteudo.appendChild(select);
    conteudo.appendChild(configuracaoArea);
    modal.appendChild(conteudo);
    document.body.appendChild(modal);
}

function abrirMiniJanelaDissertativa() {
    alert("Mini janela de Dissertativa (em breve)");
}

function renderizarFormularioTipo(tipo, container) {
    container.innerHTML = ""; // Limpa o conteúdo anterior

    if (tipo === "multipla-escolha") {
        const tituloInput = document.createElement("input");
        tituloInput.type = "text";
        tituloInput.placeholder = "Digite o título da pergunta";
        tituloInput.className = "input-titulo-pergunta";

        const alternativasContainer = document.createElement("div");
        alternativasContainer.className = "alternativas-container";

        function adicionarAlternativa(valor = "", nota = 0) {
            const linha = document.createElement("div");
            linha.className = "linha-alternativa";
            linha.style.display = "flex";
            linha.style.alignItems = "center";
            linha.style.gap = "8px";
            linha.style.marginBottom = "6px";

            const inputTexto = document.createElement("input");
            inputTexto.type = "text";
            inputTexto.placeholder = "Alternativa";
            inputTexto.value = valor;
            inputTexto.style.flex = "1";

            const inputNota = document.createElement("input");
            inputNota.type = "number";
            inputNota.min = "0";
            inputNota.max = "100";
            inputNota.value = nota;
            inputNota.className = "input-nota";
            inputNota.style.width = "80px";

            const btnExcluir = document.createElement("button");
            btnExcluir.textContent = "🗑️";
            btnExcluir.title = "Excluir alternativa";
            btnExcluir.addEventListener("click", () => {
                linha.remove();
            });

            linha.appendChild(inputTexto);
            linha.appendChild(inputNota);
            linha.appendChild(btnExcluir);
            alternativasContainer.appendChild(linha);
        }

        adicionarAlternativa();
        adicionarAlternativa();

        const btnAddAlternativa = document.createElement("button");
        btnAddAlternativa.textContent = "Adicionar Alternativa";
        btnAddAlternativa.className = "btn-add-alternativa";
        btnAddAlternativa.addEventListener("click", () => {
            adicionarAlternativa();
        });

        const btnAdicionarAoProjeto = document.createElement("button");
        btnAdicionarAoProjeto.textContent = "Adicionar ao Projeto";
        btnAdicionarAoProjeto.className = "btn-confirmar-widget";

        btnAdicionarAoProjeto.addEventListener("click", () => {
            const titulo = tituloInput.value.trim();
            if (!titulo) {
                alert("Por favor, insira um título.");
                return;
            }

            const alternativas = [];
            alternativasContainer.querySelectorAll(".linha-alternativa").forEach(linha => {
                const texto = linha.querySelector("input[type='text']").value.trim();
                const nota = parseInt(linha.querySelector("input[type='number']").value);
                if (texto) {
                    alternativas.push({ texto, nota });
                }
            });

            if (alternativas.length < 2) {
                alert("Insira ao menos duas alternativas.");
                return;
            }

            adicionarNaScrollBox({
                tipo: "multipla-escolha",
                titulo,
                alternativas
            });

            document.querySelector(".mini-janela-modal")?.remove();
        });

        container.appendChild(tituloInput);
        container.appendChild(alternativasContainer);
        container.appendChild(btnAddAlternativa);
        container.appendChild(btnAdicionarAoProjeto);
    } 
    
    else if (tipo === "verdadeiro/falso" || tipo === "verdadeiro-falso") {
        const tituloInput = document.createElement("input");
        tituloInput.type = "text";
        tituloInput.placeholder = "Digite o título da pergunta";
        tituloInput.className = "input-titulo-pergunta";

        const opcoes = ["Verdadeiro", "Falso"];
        const opcoesContainer = document.createElement("div");
        opcoesContainer.className = "vf-opcoes-container";

        const valores = {};

        opcoes.forEach(opcao => {
            const linha = document.createElement("div");
            linha.className = "linha-alternativa";

            const label = document.createElement("label");
            label.textContent = opcao;

            const inputNota = document.createElement("input");
            inputNota.type = "number";
            inputNota.min = 0;
            inputNota.max = 100;
            inputNota.value = 0;
            inputNota.className = "input-nota";
            inputNota.addEventListener("input", () => {
                valores[opcao] = parseInt(inputNota.value);
            });

            linha.appendChild(label);
            linha.appendChild(inputNota);
            opcoesContainer.appendChild(linha);

            valores[opcao] = 0; // valor inicial
        });

        const btnAdicionarAoProjeto = document.createElement("button");
        btnAdicionarAoProjeto.textContent = "Adicionar ao Projeto";
        btnAdicionarAoProjeto.className = "btn-confirmar-widget";

        btnAdicionarAoProjeto.addEventListener("click", () => {
            const titulo = tituloInput.value.trim();
            if (!titulo) {
                alert("Por favor, insira um título.");
                return;
            }

            adicionarNaScrollBox({
                tipo: "verdadeiro-falso",
                titulo,
                alternativas: [
                    { texto: "Verdadeiro", nota: valores["Verdadeiro"] },
                    { texto: "Falso", nota: valores["Falso"] }
                ]
            });

            document.querySelector(".mini-janela-modal")?.remove();
        });

        container.appendChild(tituloInput);
        container.appendChild(opcoesContainer);
        container.appendChild(btnAdicionarAoProjeto);
    }

    else if (tipo === "relacione-as-colunas") {
        const tituloInput = document.createElement("input");
        tituloInput.type = "text";
        tituloInput.placeholder = "Digite o título da pergunta";
        tituloInput.className = "input-titulo-pergunta";

        const paresContainer = document.createElement("div");
        paresContainer.className = "relacione-pares-container";

        function adicionarPar(termo = "", resposta = "", nota = 0) {
            const linha = document.createElement("div");
            linha.className = "linha-relacionar";

            const inputTermo = document.createElement("input");
            inputTermo.type = "text";
            inputTermo.placeholder = "Termo";
            inputTermo.value = termo;

            const inputResposta = document.createElement("input");
            inputResposta.type = "text";
            inputResposta.placeholder = "Resposta";
            inputResposta.value = resposta;

            const inputNota = document.createElement("input");
            inputNota.type = "number";
            inputNota.min = "0";
            inputNota.max = "100";
            inputNota.value = nota;
            inputNota.className = "input-nota";

            const btnExcluir = document.createElement("button");
            btnExcluir.textContent = "🗑️";
            btnExcluir.title = "Excluir par";
            btnExcluir.addEventListener("click", () => {
                linha.remove();
            });

            linha.appendChild(inputTermo);
            linha.appendChild(inputResposta);
            linha.appendChild(inputNota);
            linha.appendChild(btnExcluir);
            paresContainer.appendChild(linha);
        }

        adicionarPar();
        adicionarPar();

        const btnAddPar = document.createElement("button");
        btnAddPar.textContent = "Adicionar Par";
        btnAddPar.className = "btn-add-alternativa";
        btnAddPar.addEventListener("click", () => {
            adicionarPar();
        });

        const btnAdicionarAoProjeto = document.createElement("button");
        btnAdicionarAoProjeto.textContent = "Adicionar ao Projeto";
        btnAdicionarAoProjeto.className = "btn-confirmar-widget";

        btnAdicionarAoProjeto.addEventListener("click", () => {
            const titulo = tituloInput.value.trim();
            if (!titulo) {
                alert("Por favor, insira um título.");
                return;
            }

            const pares = [];
            paresContainer.querySelectorAll(".linha-relacionar").forEach(linha => {
                const termo = linha.querySelectorAll("input")[0].value.trim();
                const resposta = linha.querySelectorAll("input")[1].value.trim();
                const nota = parseInt(linha.querySelectorAll("input")[2].value);
                if (termo && resposta) {
                    pares.push({ termo, resposta, nota });
                }
            });

            if (pares.length < 2) {
                alert("Insira ao menos dois pares.");
                return;
            }

            adicionarNaScrollBox({
                tipo: "relacione-as-colunas",
                titulo,
                pares
            });

            document.querySelector(".mini-janela-modal")?.remove();
        });

        container.appendChild(tituloInput);
        container.appendChild(paresContainer);
        container.appendChild(btnAddPar);
        container.appendChild(btnAdicionarAoProjeto);
    }

    else if (tipo === "escala-likert") {
        const tabela = document.createElement("table");
        tabela.className = "tabela-likert";

        // Cabeçalho
        const cabecalho = document.createElement("tr");
        cabecalho.innerHTML = `
            <th></th>
            <th>Concordo<br>Plenamente</th>
            <th>Concordo</th>
            <th>Neutro</th>
            <th>Discordo</th>
            <th>Discordo<br>Plenamente</th>
            <th></th>
        `;
        tabela.appendChild(cabecalho);

        const corpoTabela = document.createElement("tbody");

        function adicionarLinha(pergunta = "", notas = [5, 4, 3, 2, 1]) {
            const linha = document.createElement("tr");

            const tdPergunta = document.createElement("td");
            const inputPergunta = document.createElement("input");
            inputPergunta.type = "text";
            inputPergunta.placeholder = "Digite a pergunta";
            inputPergunta.value = pergunta;
            tdPergunta.appendChild(inputPergunta);
            linha.appendChild(tdPergunta);

            notas.forEach((nota, i) => {
                const tdNota = document.createElement("td");
                const inputNota = document.createElement("input");
                inputNota.type = "number";
                inputNota.min = "0";
                inputNota.max = "100";
                inputNota.value = nota;
                inputNota.className = "input-nota";
                tdNota.appendChild(inputNota);
                linha.appendChild(tdNota);
            });

            const tdExcluir = document.createElement("td");
            const btnExcluir = document.createElement("button");
            btnExcluir.textContent = "🗑️";
            btnExcluir.title = "Excluir linha";
            btnExcluir.addEventListener("click", () => linha.remove());
            tdExcluir.appendChild(btnExcluir);
            linha.appendChild(tdExcluir);

            corpoTabela.appendChild(linha);
        }

        // Adiciona uma linha inicial
        adicionarLinha();

        tabela.appendChild(corpoTabela);

        // Botão para adicionar linha
        const btnAddLinha = document.createElement("button");
        btnAddLinha.textContent = "Adicionar Pergunta";
        btnAddLinha.className = "btn-add-linha";
        btnAddLinha.addEventListener("click", () => {
            adicionarLinha();
        });

        // Botão para preencher uma coluna com a mesma nota
        const btnDistribuir = document.createElement("button");
        btnDistribuir.textContent = "Distribuir Nota por Coluna";
        btnDistribuir.className = "btn-distribuir-nota";
        btnDistribuir.addEventListener("click", () => {
            const colIndex = prompt("Informe o número da coluna (1 a 5):");
            const notaValor = prompt("Informe a nota a ser distribuída (0 a 100):");

            const col = parseInt(colIndex, 10);
            const nota = parseInt(notaValor, 10);

            if (col >= 1 && col <= 5 && nota >= 0 && nota <= 100) {
                corpoTabela.querySelectorAll("tr").forEach(linha => {
                    const input = linha.querySelectorAll("td input")[col];
                    if (input) input.value = nota;
                });
            } else {
                alert("Coluna ou nota inválida.");
            }
        });

        const btnAdicionarAoProjeto = document.createElement("button");
        btnAdicionarAoProjeto.textContent = "Adicionar ao Projeto";
        btnAdicionarAoProjeto.className = "btn-confirmar-widget";

        btnAdicionarAoProjeto.addEventListener("click", () => {
            const perguntas = [];
            corpoTabela.querySelectorAll("tr").forEach(linha => {
                const tds = linha.querySelectorAll("td");
                const pergunta = tds[0].querySelector("input").value.trim();
                if (!pergunta) return;

                const notas = Array.from(tds)
                    .slice(1, 6)
                    .map(td => parseInt(td.querySelector("input")?.value || "0"));

                perguntas.push({ pergunta, notas });
            });

            if (!perguntas.length) {
                alert("Adicione ao menos uma pergunta.");
                return;
            }

            adicionarNaScrollBox({
                tipo: "escala-likert",
                perguntas
            });

            document.querySelector(".mini-janela-modal")?.remove();
        });

        container.appendChild(tabela);
        container.appendChild(btnAddLinha);
        container.appendChild(btnDistribuir);
        container.appendChild(btnAdicionarAoProjeto);
    }
    
    else if (tipo === "texto") {
        const tituloInput = document.createElement("input");
        tituloInput.type = "text";
        tituloInput.placeholder = "Digite o título da pergunta";
        tituloInput.className = "input-titulo-pergunta";

        const descricaoNotaContainer = document.createElement("div");
        descricaoNotaContainer.className = "descricao-nota-container";
        descricaoNotaContainer.style.display = "flex";
        descricaoNotaContainer.style.alignItems = "center";
        descricaoNotaContainer.style.gap = "16px"; // Espaço entre a descrição e a nota

        const descricaoInput = document.createElement("input");
        descricaoInput.type = "text";
        descricaoInput.placeholder = "Digite a descrição";
        descricaoInput.className = "input-descricao";
        descricaoInput.style.flex = "1"; // Para garantir que ocupe o espaço disponível

        const inputNota = document.createElement("input");
        inputNota.type = "number";
        inputNota.min = "0";
        inputNota.max = "100";
        inputNota.value = 0;
        inputNota.className = "input-nota";
        inputNota.style.width = "80px"; // Ajuste de largura para a nota

        descricaoNotaContainer.appendChild(descricaoInput);
        descricaoNotaContainer.appendChild(inputNota);

        const btnAdicionarAoProjeto = document.createElement("button");
        btnAdicionarAoProjeto.textContent = "Adicionar ao Projeto";
        btnAdicionarAoProjeto.className = "btn-confirmar-widget";

        btnAdicionarAoProjeto.addEventListener("click", () => {
            const titulo = tituloInput.value.trim();
            const descricao = descricaoInput.value.trim();
            const nota = parseInt(inputNota.value);

            if (!titulo || !descricao) {
                alert("Por favor, insira tanto o título quanto a descrição.");
                return;
            }

            // Adiciona o widget na scrollBox
            adicionarNaScrollBox({
                tipo: "texto",
                titulo,
                nota
            });

            document.querySelector(".mini-janela-modal")?.remove();
        });

        container.appendChild(tituloInput);
        container.appendChild(descricaoNotaContainer);
        container.appendChild(btnAdicionarAoProjeto);
    }

}
    
function adicionarNaScrollBox(widgetConfig) {
    const tipo = widgetConfig.tipo;
    const scrollBoxId = `scrollbox-${tipo}`;
    let scrollBox = document.getElementById(scrollBoxId);

    if (!scrollBox) {
        scrollBox = document.createElement("div");
        scrollBox.id = scrollBoxId;
        scrollBox.className = "scroll-box-widget";
        
        const titulo = document.createElement("h3");
        titulo.textContent = tipo.replace(/-/g, ' ').toUpperCase();
        titulo.className = "scrollbox-titulo";

        scrollBox.appendChild(titulo);
        document.getElementById("miniaturas-widgets").appendChild(scrollBox);
    }

    const botao = document.createElement("div");
    botao.className = "botao-widget";
    botao.draggable = true;

    // Define um título adequado baseado no tipo
    let textoTitulo = "";
    let notaTotal = 0;

    switch (tipo) {
        case "multipla-escolha":
        case "verdadeiro/falso":
        case "relacione-as-colunas":
        case "texto":
            textoTitulo = widgetConfig.titulo;
            notaTotal = widgetConfig.nota || 0;
            break;
        case "escala-likert":
            textoTitulo = "Escala Likert";
            notaTotal = widgetConfig.perguntas.reduce((acc, p) => acc + p.notas.reduce((a, b) => a + b, 0), 0);
            break;
        default:
            textoTitulo = "Widget";
    }

    const spanTitulo = document.createElement("span");
    spanTitulo.textContent = textoTitulo;

    const spanNota = document.createElement("span");
    spanNota.textContent = `Nota: ${notaTotal}`;
    spanNota.className = "nota-total";

    const iconeEditar = document.createElement("button");
    iconeEditar.textContent = "✏️";
    iconeEditar.title = "Editar";
    iconeEditar.addEventListener("click", () => {
        alert("Função de edição ainda não implementada.");
    });

    const iconeExcluir = document.createElement("button");
    iconeExcluir.textContent = "❌";
    iconeExcluir.title = "Excluir";
    iconeExcluir.addEventListener("click", () => {
        botao.remove();
        // Remove scrollbox se estiver vazia
        if (scrollBox.querySelectorAll(".botao-widget").length === 0) {
            scrollBox.remove();
        }
    });

    botao.appendChild(spanTitulo);
    botao.appendChild(spanNota);
    botao.appendChild(iconeEditar);
    botao.appendChild(iconeExcluir);

    botao.addEventListener("dblclick", () => {
        switch (widgetConfig.tipo) {
            case 'multipla-escolha':
                adicionarAoCanvasMultiplaEscolha(widgetConfig);
                break;
            case 'verdadeiro-falso':
                adicionarAoCanvasVerdadeiroFalso(widgetConfig);
                break;
            case 'relacione-as-colunas':
                adicionarAoCanvasRelacioneColunas(widgetConfig);
                break;
            case 'escala-likert':
                adicionarAoCanvasLikert(widgetConfig);
                break;
            case 'texto':
                adicionarAoCanvasTexto(widgetConfig);
                break;
            default:
                alert("Tipo de widget desconhecido.");
        }
    });

    scrollBox.appendChild(botao);
}

function adicionarAoCanvasMultiplaEscolha(widgetConfig) {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
        alert("Canvas não encontrado.");
        return;
    }

    const botaoWidget = document.createElement("div");
    botaoWidget.className = "botao-widget-canvas";

    const titulo = document.createElement("h4");
    titulo.textContent = widgetConfig.titulo;

    const alternativasContainer = document.createElement("div");
    alternativasContainer.className = "alternativas-container";

    // Adicionando as alternativas
    widgetConfig.alternativas.forEach(alt => {
        const alternativa = document.createElement("div");
        alternativa.className = "alternativa";

        const inputAlternativa = document.createElement("input");
        inputAlternativa.type = "radio";
        inputAlternativa.name = widgetConfig.titulo;
        inputAlternativa.value = alt.texto;

        const textoAlternativa = document.createElement("span");
        textoAlternativa.textContent = alt.texto;

        alternativa.appendChild(inputAlternativa);
        alternativa.appendChild(textoAlternativa);
        alternativasContainer.appendChild(alternativa);
    });

    botaoWidget.appendChild(titulo);
    botaoWidget.appendChild(alternativasContainer);
    canvas.appendChild(botaoWidget);
}

function adicionarAoCanvasVerdadeiroFalso(widgetConfig) {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
        alert("Canvas não encontrado.");
        return;
    }

    const botaoWidget = document.createElement("div");
    botaoWidget.className = "botao-widget-canvas";

    const titulo = document.createElement("h4");
    titulo.textContent = widgetConfig.titulo;

    const alternativasContainer = document.createElement("div");
    alternativasContainer.className = "alternativas-container";

    // Adicionando as alternativas Verdadeiro e Falso
    const alternativas = ["Verdadeiro", "Falso"];
    alternativas.forEach(alt => {
        const alternativa = document.createElement("div");
        alternativa.className = "alternativa";

        const inputAlternativa = document.createElement("input");
        inputAlternativa.type = "radio";
        inputAlternativa.name = widgetConfig.titulo;
        inputAlternativa.value = alt;

        const textoAlternativa = document.createElement("span");
        textoAlternativa.textContent = alt;

        alternativa.appendChild(inputAlternativa);
        alternativa.appendChild(textoAlternativa);
        alternativasContainer.appendChild(alternativa);
    });

    botaoWidget.appendChild(titulo);
    botaoWidget.appendChild(alternativasContainer);
    canvas.appendChild(botaoWidget);
}

function adicionarAoCanvasRelacioneColunas(widgetConfig) {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
        alert("Canvas não encontrado.");
        return;
    }

    const botaoWidget = document.createElement("div");
    botaoWidget.className = "botao-widget-canvas";

    const titulo = document.createElement("h4");
    titulo.textContent = widgetConfig.titulo;

    // Criando as duas colunas
    const col1 = document.createElement("div");
    col1.className = "coluna";

    const col2 = document.createElement("div");
    col2.className = "coluna";

    // Adicionando itens nas colunas
    widgetConfig.itensColuna1.forEach(item => {
        const divItem = document.createElement("div");
        divItem.textContent = item;
        col1.appendChild(divItem);
    });

    widgetConfig.itensColuna2.forEach(item => {
        const divItem = document.createElement("div");
        divItem.textContent = item;
        col2.appendChild(divItem);
    });

    const containerColunas = document.createElement("div");
    containerColunas.className = "relacao-colunas";
    containerColunas.appendChild(col1);
    containerColunas.appendChild(col2);

    botaoWidget.appendChild(titulo);
    botaoWidget.appendChild(containerColunas);
    canvas.appendChild(botaoWidget);
}

function adicionarAoCanvasLikert(widgetConfig) {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
        alert("Canvas não encontrado.");
        return;
    }

    const botaoWidget = document.createElement("div");
    botaoWidget.className = "botao-widget-canvas";

    const titulo = document.createElement("h4");
    titulo.textContent = widgetConfig.titulo;

    const alternativasContainer = document.createElement("div");
    alternativasContainer.className = "alternativas-container";

    // Adicionando as alternativas de 1 a 5
    for (let i = 1; i <= 5; i++) {
        const alternativa = document.createElement("div");
        alternativa.className = "alternativa";

        const inputAlternativa = document.createElement("input");
        inputAlternativa.type = "radio";
        inputAlternativa.name = widgetConfig.titulo;
        inputAlternativa.value = i;

        const textoAlternativa = document.createElement("span");
        textoAlternativa.textContent = `${i}`;

        alternativa.appendChild(inputAlternativa);
        alternativa.appendChild(textoAlternativa);
        alternativasContainer.appendChild(alternativa);
    }

    botaoWidget.appendChild(titulo);
    botaoWidget.appendChild(alternativasContainer);
    canvas.appendChild(botaoWidget);
}

function adicionarAoCanvasTexto(widgetConfig) {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
        alert("Canvas não encontrado.");
        return;
    }

    const botaoWidget = document.createElement("div");
    botaoWidget.className = "botao-widget-canvas";

    const titulo = document.createElement("h4");
    titulo.textContent = widgetConfig.titulo;

    const textarea = document.createElement("textarea");
    textarea.placeholder = "Digite seu texto aqui...";

    botaoWidget.appendChild(titulo);
    botaoWidget.appendChild(textarea);
    canvas.appendChild(botaoWidget);
}
