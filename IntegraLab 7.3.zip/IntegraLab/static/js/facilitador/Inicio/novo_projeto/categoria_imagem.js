import { adicionarElementoCustomizado } from './canvas.js'; 

document.addEventListener('DOMContentLoaded', () => {
    const inputImagem = document.getElementById('input-imagem');
    const containerMiniaturas = document.getElementById('miniaturas-imagem');

    if (!inputImagem || !containerMiniaturas) return;

    inputImagem.addEventListener('change', () => {
        Array.from(inputImagem.files).forEach(file => {
            if (!file.type.startsWith('image/')) {
                alert("Por favor, selecione um arquivo de imagem.");
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const src = e.target.result;

                const miniaturaContainer = document.createElement('div');
                miniaturaContainer.classList.add('miniatura-container');
                miniaturaContainer.setAttribute('data-src', src); // IMPORTANTE para rastrear

                const img = document.createElement('img');
                img.src = src;
                img.classList.add('miniatura');
                img.setAttribute('data-src', src);

                // Duplo clique para adicionar ao canvas
                img.addEventListener('dblclick', () => {
                    adicionarElementoCustomizado('img', src);
                });

                // Drag & Drop
                img.draggable = true;
                img.addEventListener('dragstart', (ev) => {
                    ev.dataTransfer.setData('text/plain', src);
                    ev.dataTransfer.setData('tipo', 'img');
                });

                // Botão de exclusão
                const btnExcluir = document.createElement('button');
                btnExcluir.innerText = '❌';
                btnExcluir.classList.add('btn-excluir');
                btnExcluir.addEventListener('click', () => {
                    miniaturaContainer.remove();

                    // Remove do canvas qualquer wrapper com o mesmo data-src
                    const canvas = document.getElementById('canvas');
                    if (canvas) {
                        const elementos = canvas.querySelectorAll('.resizable-wrapper[data-src]');
                        elementos.forEach(el => {
                            if (el.getAttribute('data-src') === src) {
                                el.remove();
                            }
                        });
                    }
                });

                miniaturaContainer.appendChild(img);
                miniaturaContainer.appendChild(btnExcluir);
                containerMiniaturas.appendChild(miniaturaContainer);
            };

            reader.readAsDataURL(file);
        });

        inputImagem.value = ''; // Permite reupload do mesmo arquivo
    });
});
