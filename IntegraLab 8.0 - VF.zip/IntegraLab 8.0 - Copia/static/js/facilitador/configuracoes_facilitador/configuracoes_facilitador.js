// Função para salvar as configurações personalizadas do usuário
document.getElementById('form-configuracoes').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtendo as cores escolhidas pelo usuário
    const corFundo = document.getElementById('cor-fundo').value;
    const corPrimaria = document.getElementById('cor-primaria').value;
    const corSecundaria = document.getElementById('cor-secundaria').value;

    // Aplicando as cores ao corpo da página e ao cabeçalho
    document.body.style.backgroundColor = corFundo;
    document.querySelector('.header').style.background = `linear-gradient(45deg, ${corPrimaria}, ${corSecundaria})`;

    // Salvando as preferências no localStorage para persistência
    localStorage.setItem('corFundo', corFundo);
    localStorage.setItem('corPrimaria', corPrimaria);
    localStorage.setItem('corSecundaria', corSecundaria);
});

// Função para redefinir as cores para os valores padrão
document.querySelector('button[type="reset"]').addEventListener('click', function() {
    // Definindo as cores padrão
    const corFundoPadrao = '#121212';
    const corPrimariaPadrao = '#ff416c';
    const corSecundariaPadrao = '#ff4b2b';

    // Aplicando as cores padrão
    document.body.style.backgroundColor = corFundoPadrao;
    document.querySelector('.header').style.background = `linear-gradient(45deg, ${corPrimariaPadrao}, ${corSecundariaPadrao})`;

    // Limpar as preferências armazenadas
    localStorage.removeItem('corFundo');
    localStorage.removeItem('corPrimaria');
    localStorage.removeItem('corSecundaria');
});

// Função para alterar o tema rapidamente
function alterarTema(tema) {
    let corFundo, corPrimaria, corSecundaria;

    if (tema === 'tema1') {
        corFundo = '#121212';
        corPrimaria = '#ff416c';
        corSecundaria = '#ff4b2b';
    } else if (tema === 'tema2') {
        corFundo = '#2c3e50';
        corPrimaria = '#3498db';
        corSecundaria = '#8e44ad';
    } else if (tema === 'tema3') {
        corFundo = '#f5f5f5';
        corPrimaria = '#2ecc71';
        corSecundaria = '#27ae60';
    }

    // Aplicando as cores do tema selecionado
    document.body.style.backgroundColor = corFundo;
    document.querySelector('.header').style.background = `linear-gradient(45deg, ${corPrimaria}, ${corSecundaria})`;

    // Salvando as configurações do tema no localStorage
    localStorage.setItem('corFundo', corFundo);
    localStorage.setItem('corPrimaria', corPrimaria);
    localStorage.setItem('corSecundaria', corSecundaria);
}

// Função para carregar as configurações salvas ao carregar a página
window.addEventListener('load', function() {
    const corFundo = localStorage.getItem('corFundo');
    const corPrimaria = localStorage.getItem('corPrimaria');
    const corSecundaria = localStorage.getItem('corSecundaria');

    // Verificando se há configurações salvas no localStorage e aplicando
    if (corFundo && corPrimaria && corSecundaria) {
        document.body.style.backgroundColor = corFundo;
        document.querySelector('.header').style.background = `linear-gradient(45deg, ${corPrimaria}, ${corSecundaria})`;

        // Atualizando os inputs do formulário para refletir as cores salvas
        document.getElementById('cor-fundo').value = corFundo;
        document.getElementById('cor-primaria').value = corPrimaria;
        document.getElementById('cor-secundaria').value = corSecundaria;
    }
});
