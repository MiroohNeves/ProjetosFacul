document.addEventListener('DOMContentLoaded', function() {
    // Função para alternar a visibilidade do formulário
    function toggleForm() {
        var formContainer = document.getElementById('form-container');
        var icon = document.getElementById('toggle-icon');
        var camposExtras = document.querySelectorAll('.campo-oculto');

        if (formContainer.classList.contains('hidden')) {
            formContainer.classList.remove('hidden');
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
            camposExtras.forEach(function(campo) {
                campo.style.display = 'block';
            });
        } else {
            formContainer.classList.add('hidden');
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
            camposExtras.forEach(function(campo) {
                campo.style.display = 'none';
            });
        }
    }

    // Função para fazer a primeira letra maiúscula no nome e no supervisor
    function capitalizeFirstLetter() {
        var nome = document.getElementById('nome');
        var supervisor = document.getElementById('supervisor');
        
        // Garantir que a primeira letra seja maiúscula
        nome.value = nome.value.charAt(0).toUpperCase() + nome.value.slice(1);
        supervisor.value = supervisor.value.charAt(0).toUpperCase() + supervisor.value.slice(1);
    }

    // Chamar a função capitalizeFirstLetter ao submeter o formulário
    document.getElementById('form-adicionar').addEventListener('submit', function(event) {
        capitalizeFirstLetter();
    });

    // Adiciona o evento de clique ao botão
    var toggleButton = document.querySelector('.toggle-btn');
    if (toggleButton) {
        toggleButton.addEventListener('click', toggleForm);
    }
});
