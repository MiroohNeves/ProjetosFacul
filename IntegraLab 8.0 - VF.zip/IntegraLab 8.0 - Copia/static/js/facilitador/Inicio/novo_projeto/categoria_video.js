import { adicionarElementoCustomizado } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const inputVideo = document.getElementById('input-video');
    const containerMiniaturas = document.getElementById('miniaturas-video');

    if (!inputVideo || !containerMiniaturas) return;

    inputVideo.addEventListener('change', () => {
        Array.from(inputVideo.files).forEach(file => {
            if (!file.type.startsWith('video/')) {
                alert("Por favor, selecione um arquivo de vídeo.");
                return;
            }

            const videoUrl = URL.createObjectURL(file);

            const miniaturaContainer = document.createElement('div');
            miniaturaContainer.classList.add('miniatura-container');
            miniaturaContainer.setAttribute('data-src', videoUrl);

            const videoElement = document.createElement('video');
            videoElement.src = videoUrl;
            videoElement.classList.add('miniatura');
            videoElement.width = 100;
            videoElement.height = 75;
            videoElement.loop = true;
            videoElement.preload = 'metadata';

            // Botão play/pause
            const btnPlayPause = document.createElement('button');
            btnPlayPause.textContent = '▶️';
            btnPlayPause.classList.add('btn-play-pause');
            btnPlayPause.addEventListener('click', () => {
                togglePlayPause(videoElement, btnPlayPause);
            });

            // Duplo clique para adicionar ao canvas
            videoElement.addEventListener('dblclick', () => {
                adicionarElementoCustomizado('video', videoUrl);
            });

            // Drag & Drop
            videoElement.draggable = true;
            videoElement.addEventListener('dragstart', (ev) => {
                ev.dataTransfer.setData('text/plain', videoUrl);
                ev.dataTransfer.setData('tipo', 'video');
            });

            // Botão de exclusão
            const btnExcluir = document.createElement('button');
            btnExcluir.innerText = '❌';
            btnExcluir.classList.add('btn-excluir');
            btnExcluir.addEventListener('click', () => {
                // Remove a miniatura
                miniaturaContainer.remove();
                URL.revokeObjectURL(videoUrl);

                // Remove também o vídeo correspondente do canvas
                const canvas = document.getElementById('canvas'); // ID do container do canvas
                if (canvas) {
                    const elementosCanvas = canvas.querySelectorAll('[data-src]');
                    elementosCanvas.forEach(el => {
                        if (el.getAttribute('data-src') === videoUrl) {
                            el.remove();
                        }
                    });
                }
            });

            // Adiciona os elementos ao container
            miniaturaContainer.appendChild(videoElement);
            miniaturaContainer.appendChild(btnPlayPause);
            miniaturaContainer.appendChild(btnExcluir);
            containerMiniaturas.appendChild(miniaturaContainer);
        });

        inputVideo.value = '';
    });

    function togglePlayPause(videoEl, btn) {
        if (videoEl.paused || videoEl.ended) {
            videoEl.play()
                .then(() => {
                    btn.textContent = '⏸️';
                })
                .catch(error => {
                    console.error('Erro ao reproduzir o vídeo:', error);
                    alert('Interaja com a página antes de reproduzir o vídeo com som.');
                });
        } else {
            videoEl.pause();
            btn.textContent = '▶️';
        }
    }
});
