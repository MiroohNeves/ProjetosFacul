document.getElementById("salvar-projeto").addEventListener("click", () => {
    const titulo = document.getElementById("titulo-projeto").value;
    const canvasElementos = Array.from(document.querySelectorAll(".canvas-elemento"));

    const projeto = {
        titulo,
        paginas: []
    };

    canvasElementos.forEach(el => {
        const pagina = el.dataset.pagina || 0;
        if (!projeto.paginas[pagina]) projeto.paginas[pagina] = [];

        projeto.paginas[pagina].push({
            tipo: el.dataset.tipo,
            conteudo: el.src || el.textContent,
            estilo: {
                top: el.style.top,
                left: el.style.left,
                width: el.style.width,
                height: el.style.height
            }
        });
    });

    console.log("Projeto salvo:", projeto);
    alert("Projeto salvo no console (JSON)!");
});
