import { adicionarElementoCustomizado } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const inputAudio = document.getElementById('input-audio');
    const containerMiniaturas = document.getElementById('miniaturas-audio');

    if (!inputAudio || !containerMiniaturas) return;

    inputAudio.addEventListener('change', () => {
        Array.from(inputAudio.files).forEach(file => {
            if (!file.type.startsWith('audio/')) {
                alert("Por favor, selecione um arquivo de áudio.");
                return;
            }

            const audioUrl = URL.createObjectURL(file);
            const nomeAudio = file.name;

            const miniaturaContainer = document.createElement('div');
            miniaturaContainer.classList.add('miniatura-container');
            miniaturaContainer.setAttribute('data-src', audioUrl);

            const audioElement = document.createElement('audio');
            audioElement.src = audioUrl;
            audioElement.style.display = 'none';

            const audioLabel = document.createElement('div');
            audioLabel.classList.add('miniatura');
            audioLabel.textContent = nomeAudio;

            // Estilos aplicados ao áudioLabel para que ele tenha o mesmo formato da miniatura
            audioLabel.style.display = 'flex'; // Usar flexbox para alinhar o nome do áudio corretamente
            audioLabel.style.flexDirection = 'column'; // Para que o texto fique em coluna
            audioLabel.style.justifyContent = 'center'; // Centraliza o texto no centro da miniatura
            audioLabel.style.alignItems = 'center'; // Centraliza o texto horizontalmente
            audioLabel.style.fontSize = '12px'; // Tamanho do texto reduzido
            audioLabel.style.wordWrap = 'break-word'; // Permite quebra de linha
            audioLabel.style.whiteSpace = 'normal';  // Permite que o texto ocupe várias linhas
            audioLabel.style.overflow = 'hidden';    // Impede que o texto ultrapasse os limites
            audioLabel.style.textOverflow = 'ellipsis'; // Adiciona "..." caso o nome seja longo demais
            audioLabel.style.padding = '5px'; // Adiciona um padding para dar um espaço no texto

            // Duplo clique para adicionar ao canvas
            audioLabel.addEventListener('dblclick', () => {
                adicionarElementoCustomizado('audio', audioUrl);
            });

            // Drag & Drop
            audioLabel.draggable = true;
            audioLabel.addEventListener('dragstart', (ev) => {
                ev.dataTransfer.setData('text/plain', audioUrl);
                ev.dataTransfer.setData('tipo', 'audio');
            });

            // Botão play/pause
            const btnPlayPause = document.createElement('button');
            btnPlayPause.textContent = '▶️';
            btnPlayPause.classList.add('btn-play-pause');
            btnPlayPause.addEventListener('click', () => {
                togglePlayPause(audioElement, btnPlayPause);
            });

            // Botão excluir
            const btnExcluir = document.createElement('button');
            btnExcluir.textContent = '❌';
            btnExcluir.classList.add('btn-excluir');
            btnExcluir.addEventListener('click', () => {
                miniaturaContainer.remove();
                URL.revokeObjectURL(audioUrl);

                // Também remove o áudio do canvas
                const canvas = document.getElementById('canvas');
                if (canvas) {
                    const elementosCanvas = canvas.querySelectorAll('.resizable-wrapper[data-src]');
                    elementosCanvas.forEach(el => {
                        if (el.getAttribute('data-src') === audioUrl) {
                            el.remove();
                        }
                    });
                }
            });

            miniaturaContainer.appendChild(audioElement);
            miniaturaContainer.appendChild(audioLabel);
            miniaturaContainer.appendChild(btnPlayPause);
            miniaturaContainer.appendChild(btnExcluir);
            containerMiniaturas.appendChild(miniaturaContainer);
        });

        inputAudio.value = ''; // Permite reupload do mesmo arquivo
    });

    function togglePlayPause(audioEl, btn) {
        if (audioEl.paused) {
            audioEl.play();
            btn.textContent = '⏸️';
        } else {
            audioEl.pause();
            btn.textContent = '▶️';
        }
    }
});
