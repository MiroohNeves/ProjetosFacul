// Estado local
let elementosCanvas = [];
let paginaAtual = 0;
let paginas = [[]]; // Cada página contém seus elementos

const canvas = document.getElementById('canvas');

// Adiciona elemento (imagem, vídeo, áudio ou widget) ao canvas
export function adicionarElementoCustomizado(tipo, src, x = 50, y = 50) {
    const wrapper = document.createElement('div');
    wrapper.classList.add('resizable-wrapper');
    wrapper.setAttribute('data-src', src);
    wrapper.setAttribute('data-tipo', tipo);
    wrapper.style.position = 'absolute';
    wrapper.style.left = `${x}px`;
    wrapper.style.top = `${y}px`;

    let element;

    if (tipo === 'img' || tipo === 'video') {
        element = document.createElement(tipo);
        element.src = src;
        element.classList.add('canvas-elemento');
        element.controls = tipo === 'video';
        element.style.width = '100%';
        element.style.height = '100%';
        wrapper.appendChild(element);
    } else if (tipo === 'audio') {
        element = document.createElement('audio');
        element.src = src;
        element.classList.add('canvas-elemento');
        element.controls = true;
        element.style.width = '100%';
        wrapper.style.width = '200px';
        wrapper.style.height = '40px';
        wrapper.appendChild(element);
    } else if (tipo === 'widget') {
        let dados;
        try {
            dados = JSON.parse(src);
        } catch (e) {
            console.warn('Não é JSON de widget válido:', src);
            return;
        }

        element = document.createElement('div');
        element.classList.add('canvas-elemento');

        if (dados.tipo === 'multipla') {
            element.innerHTML += `<p><strong>${dados.enunciado}</strong></p>`;
            element.innerHTML += dados.opcoes.map((opt, i) => `
                <label>
                    <input type="radio" name="resposta-${Date.now()}" />
                    ${opt.texto}
                </label><br/>
            `).join('');
        }

        else if (dados.tipo === 'vf') {
            element.innerHTML += `<p><strong>${dados.enunciado}</strong></p>`;
            element.innerHTML += dados.opcoes.map((opt, i) => `
                <button class="btn-vf" data-opcao="${opt.texto}">
                    ${opt.texto}
                </button><br/>
            `).join('');
        }

        else if (dados.tipo === 'relacione') {
            let colA = dados.opcoes.slice(0, dados.opcoes.length / 2);
            let colB = dados.opcoes.slice(dados.opcoes.length / 2);

            let html = `
                <div class="relacao-coluna">
                    ${colA.map(opt => `<input type="text" value="${opt.texto}" class="coluna-a" />`).join('')}
                </div>
                <div class="relacao-coluna">
                    ${colB.map(opt => `<input type="text" value="${opt.texto}" class="coluna-b" />`).join('')}
                </div>
            `;
            element.innerHTML = html;

            element.querySelector('.add-row').addEventListener('click', () => {
                const newRowA = document.createElement('input');
                newRowA.type = 'text';
                element.querySelector('.relacao-coluna:nth-child(1)').appendChild(newRowA);

                const newRowB = document.createElement('input');
                newRowB.type = 'text';
                element.querySelector('.relacao-coluna:nth-child(2)').appendChild(newRowB);
            });

            element.querySelector('.remove-row').addEventListener('click', () => {
                const colA = element.querySelector('.relacao-coluna:nth-child(1)');
                const colB = element.querySelector('.relacao-coluna:nth-child(2)');

                if (colA.children.length > 0 && colB.children.length > 0) {
                    colA.removeChild(colA.lastChild);
                    colB.removeChild(colB.lastChild);
                }
            });
        }

else if (dados.tipo === 'likert') {
    let idUnico = Date.now();
    let contadorLinha = 0;

    element.innerHTML += `<p><strong>${dados.enunciado}</strong></p>`;

    const tabela = document.createElement('table');
    tabela.border = "1";
    tabela.style.width = "100%";
    tabela.style.textAlign = "center";
    tabela.style.marginTop = "10px";

    tabela.innerHTML = `
        <thead>
            <tr>
                <th></th>
                <th>Concordo Totalmente</th>
                <th>Concordo</th>
                <th>Neutro</th>
                <th>Discordo</th>
                <th>Discordo Totalmente</th>
            </tr>
        </thead>
        <tbody id="likert-body-${idUnico}">
        </tbody>
    `;

    const tbody = tabela.querySelector(`#likert-body-${idUnico}`);

    function adicionarLinhaLikert(texto = `Afirmativa ${contadorLinha + 1}`) {
        const novaLinha = document.createElement('tr');
        novaLinha.innerHTML = `
            <td>${texto}</td>
            <td><input type="radio" name="likert-${idUnico}-${contadorLinha}" value="5" /></td>
            <td><input type="radio" name="likert-${idUnico}-${contadorLinha}" value="4" /></td>
            <td><input type="radio" name="likert-${idUnico}-${contadorLinha}" value="3" /></td>
            <td><input type="radio" name="likert-${idUnico}-${contadorLinha}" value="2" /></td>
            <td><input type="radio" name="likert-${idUnico}-${contadorLinha}" value="1" /></td>
        `;
        tbody.appendChild(novaLinha);
        contadorLinha++;
    }

    // Adiciona apenas a primeira afirmativa
    adicionarLinhaLikert();

    // Adiciona a tabela ao elemento (sem botão)
    element.appendChild(tabela);
}


        else if (dados.tipo === 'dissertativa') {
            if (dados.variante === 'enunciado' || dados.variante === 'enunciado_descricao') {
                element.innerHTML += `<p><strong>${dados.enunciado}</strong></p>`;
            }

            if (dados.variante === 'descricao' || dados.variante === 'enunciado_descricao') {
                const textarea = document.createElement('textarea');
                textarea.rows = 4;
                textarea.placeholder = 'Resposta do aluno';
                textarea.style.width = '100%';
                element.appendChild(textarea);
            }
        }

        wrapper.appendChild(element);
    }

    canvas.appendChild(wrapper);
    elementosCanvas.push(wrapper);
    paginas[paginaAtual].push(wrapper);

    habilitarMovimento(wrapper);
    habilitarRedimensionamento(wrapper);
}

// Torna elementos movíveis dentro do canvas
function habilitarMovimento(wrapper) {
    let isDragging = false;
    let offsetX, offsetY;

    wrapper.addEventListener('mousedown', (e) => {
        if (e.target.tagName.toLowerCase() === 'button') return;
        isDragging = true;
        offsetX = e.offsetX;
        offsetY = e.offsetY;
        wrapper.style.zIndex = 1000;
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        const canvasRect = canvas.getBoundingClientRect();
        const x = e.clientX - canvasRect.left - offsetX;
        const y = e.clientY - canvasRect.top - offsetY;

        wrapper.style.left = `${Math.max(0, Math.min(x, canvas.clientWidth - wrapper.offsetWidth))}px`;
        wrapper.style.top = `${Math.max(0, Math.min(y, canvas.clientHeight - wrapper.offsetHeight))}px`;
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        wrapper.style.zIndex = '';
    });
}

// Torna elementos redimensionáveis
function habilitarRedimensionamento(wrapper) {
    const direcoes = ['n', 'e', 's', 'w', 'ne', 'nw', 'se', 'sw'];
    direcoes.forEach(dir => {
        const handle = document.createElement('div');
        handle.classList.add('resize-handle', dir);
        wrapper.appendChild(handle);

        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();

            const startX = e.clientX;
            const startY = e.clientY;
            const startWidth = wrapper.offsetWidth;
            const startHeight = wrapper.offsetHeight;
            const startTop = wrapper.offsetTop;
            const startLeft = wrapper.offsetLeft;

            function doDrag(e) {
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;

                if (dir.includes('e')) wrapper.style.width = `${startWidth + dx}px`;
                if (dir.includes('s')) wrapper.style.height = `${startHeight + dy}px`;
                if (dir.includes('w')) {
                    wrapper.style.width = `${startWidth - dx}px`;
                    wrapper.style.left = `${startLeft + dx}px`;
                }
                if (dir.includes('n')) {
                    wrapper.style.height = `${startHeight - dy}px`;
                    wrapper.style.top = `${startTop + dy}px`;
                }
            }

            function stopDrag() {
                document.removeEventListener('mousemove', doDrag);
                document.removeEventListener('mouseup', stopDrag);
            }

            document.addEventListener('mousemove', doDrag);
            document.addEventListener('mouseup', stopDrag);
        });
    });

    const btnRemover = document.createElement('button');
    btnRemover.innerText = '✖';
    btnRemover.classList.add('btn-remove-canvas');
    btnRemover.addEventListener('click', () => wrapper.remove());
    wrapper.appendChild(btnRemover);
}

// Muda a página atual do canvas
export function mudarPagina(index) {
    if (!paginas[index]) paginas[index] = [];

    canvas.innerHTML = '';
    paginas[index].forEach(el => canvas.appendChild(el));
    paginaAtual = index;
}

export function removerPagina(index) {
    if (!paginas[index]) return;

    paginas[index].forEach(el => {
        if (el && el.parentElement) {
            el.parentElement.removeChild(el);
        }
    });

    paginas.splice(index, 1);

    if (paginaAtual === index) {
        paginaAtual = Math.max(0, index - 1);
    } else if (paginaAtual > index) {
        paginaAtual--;
    }

    if (paginas.length > 0) {
        mudarPagina(paginaAtual);
    } else {
        paginas = [[]];
        paginaAtual = 0;
        mudarPagina(0);
    }
}

// Drag & Drop do canvas
canvas.addEventListener('dragover', (e) => e.preventDefault());

canvas.addEventListener('drop', (e) => {
    e.preventDefault();

    const src = e.dataTransfer.getData('text/plain');
    const tipo = e.dataTransfer.getData('tipo');

    if (!src || !tipo) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    adicionarElementoCustomizado(tipo, src, x, y);
});
