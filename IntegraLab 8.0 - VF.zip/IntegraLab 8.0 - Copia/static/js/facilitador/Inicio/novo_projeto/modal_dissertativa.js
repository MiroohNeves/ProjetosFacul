import { adicionarElementoCustomizado } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const buttonDissertativa = document.querySelector('[data-widget="Button_Dissertativa"]');
    buttonDissertativa.addEventListener('click', () => abrirModalDissertativa());
});

function abrirModalDissertativa() {
    const overlay = document.createElement('div');
    overlay.className = 'mini-janela-modal';
    overlay.innerHTML = `
        <div class="mini-janela-conteudo">
            <span class="fechar-mini-janela">✖</span>
            <h3>Criar Pergunta Dissertativa</h3>

            <label for="tipo-dissertativa">Selecione o tipo:</label>
            <select id="tipo-dissertativa" style="width: 100%; margin-bottom: 10px;">
                <option value="">-- Selecione --</option>
                <option value="enunciado">Somente Enunciado</option>
                <option value="enunciado_descricao">Enunciado + Caixa de Descrição</option>
                <option value="descricao">Somente Caixa de Descrição</option>
            </select>

            <div id="campos-dissertativa"></div>

            <button id="salvar-dissertativa">Salvar</button>
        </div>
    `;
    document.body.appendChild(overlay);

    const tipoSelect = overlay.querySelector('#tipo-dissertativa');
    const camposContainer = overlay.querySelector('#campos-dissertativa');

    tipoSelect.addEventListener('change', () => {
        const tipo = tipoSelect.value;
        camposContainer.innerHTML = '';

        if (tipo === 'enunciado' || tipo === 'enunciado_descricao') {
            camposContainer.innerHTML += `
                <label>Enunciado:</label>
                <textarea id="input-enunciado" rows="3" style="width: 100%;"></textarea>
            `;
        }

        if (tipo === 'descricao' || tipo === 'enunciado_descricao') {
            camposContainer.innerHTML += `
                <label>Caixa de Descrição:</label>
                <textarea id="input-descricao" rows="4" style="width: 100%;" disabled></textarea>
            `;
        }
    });

    overlay.querySelector('.fechar-mini-janela').addEventListener('click', () => overlay.remove());

    overlay.querySelector('#salvar-dissertativa').addEventListener('click', () => {
        const tipo = tipoSelect.value;
        const enunciado = overlay.querySelector('#input-enunciado')?.value.trim() || '';
        const descricao = tipo === 'descricao' || tipo === 'enunciado_descricao';

        if (!tipo || (tipo.includes('enunciado') && enunciado === '')) {
            alert('Preencha o tipo e o enunciado, se aplicável.');
            return;
        }

        const dadosPergunta = {
            tipo: 'dissertativa',
            variante: tipo,
            enunciado,
            mostrarDescricao: descricao,
        };

        adicionarMiniaturaWidgetDissertativa(dadosPergunta);
        overlay.remove();
    });
}

function obterIconeDissertativa(variante) {
    switch (variante) {
        case 'enunciado':
            return '📝'; // Enunciado
        case 'descricao':
            return '📋'; // Descrição
        case 'enunciado_descricao':
            return '📝📋'; // Ambos
        default:
            return '📄'; // Ícone padrão
    }
}

function adicionarMiniaturaWidgetDissertativa(dados) {
    const miniaturasContainer = document.getElementById('miniaturas-widgets');

    const wrapper = document.createElement('div');
    wrapper.className = 'botao-widget';
    wrapper.setAttribute('draggable', true);
    wrapper.dataset.widgetData = JSON.stringify(dados);

    const icone = obterIconeDissertativa(dados.variante);
    wrapper.innerHTML = `
        <span>${icone} Dissertativa - ${dados.variante.replace('_', ' + ')}</span>
        <button class="btn-apagar">🗑️</button>
    `;


    wrapper.querySelector('.btn-apagar').addEventListener('click', () => wrapper.remove());

    wrapper.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', JSON.stringify(dados));
        e.dataTransfer.setData('tipo', 'widget');
    });

    wrapper.addEventListener('dblclick', () => {
        adicionarElementoCustomizado('widget', JSON.stringify(dados), 100, 100);
    });

    miniaturasContainer.appendChild(wrapper);
}
