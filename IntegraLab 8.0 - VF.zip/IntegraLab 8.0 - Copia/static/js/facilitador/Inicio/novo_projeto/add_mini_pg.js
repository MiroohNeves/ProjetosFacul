import { mudarPagina, removerPagina } from './canvas.js';

let paginas = [[]]; // Inicializa com uma página vazia
let paginaAtual = 0;

document.addEventListener('DOMContentLoaded', () => {
    const btnNovaPagina = document.getElementById('nova-pagina');
    const miniaturasContainer = document.getElementById('miniaturas-paginas');

    // Cria miniatura para a primeira página (página 1)
    const miniaturaInicial = criarMiniatura(0);
    miniaturasContainer.appendChild(miniaturaInicial);

    // Quando o botão de adicionar nova página for clicado
    btnNovaPagina?.addEventListener('click', () => {
        // Adiciona nova página
        paginas.push([]); // Nova página vazia

        const novaPaginaIndex = paginas.length - 1; // Agora é seguro pegar o último índice

        const miniatura = criarMiniatura(novaPaginaIndex);
        document.getElementById('miniaturas-paginas').appendChild(miniatura);

        mudarPagina(novaPaginaIndex);
        atualizarMiniaturas(); // renomeia tudo corretamente
    });
});

// Função para criar miniatura de página com o ícone de remoção
function criarMiniatura(index) {
    const miniaturaWrapper = document.createElement('div');
    miniaturaWrapper.classList.add('miniatura-wrapper'); // Container para miniatura + botão

    const miniatura = document.createElement('button');
    miniatura.textContent = ''; // será definido depois
    miniatura.classList.add('miniatura-pagina');

    const btnRemover = document.createElement('button');
    btnRemover.innerText = '✖';
    btnRemover.classList.add('btn-remove-pagina');
    btnRemover.addEventListener('click', (e) => {
        e.stopPropagation();
        removerPagina(index);      // Usa a função centralizada
        miniaturaWrapper.remove(); // Remove a miniatura da interface
        atualizarMiniaturas();
    });

    miniaturaWrapper.appendChild(miniatura); // Adiciona o botão da miniatura
    miniaturaWrapper.appendChild(btnRemover); // Adiciona o ícone de exclusão

    miniatura.addEventListener('click', () => {
        mudarPagina(index); // Muda para a página correspondente
    });

    return miniaturaWrapper; // Retorna o wrapper com miniatura e botão de remoção
}

// Função para atualizar as miniaturas e renomeá-las corretamente
function atualizarMiniaturas() {
    const miniaturasContainer = document.getElementById('miniaturas-paginas');
    const miniaturas = miniaturasContainer.querySelectorAll('.miniatura-wrapper');

    miniaturas.forEach((miniaturaWrapper, index) => {
        const miniatura = miniaturaWrapper.querySelector('.miniatura-pagina');
        const btnRemover = miniaturaWrapper.querySelector('.btn-remove-pagina');

        miniatura.textContent = `Página ${index + 1}`;

        // Atualiza evento de clique
        miniatura.onclick = () => mudarPagina(index);
        btnRemover.onclick = (e) => {
            e.stopPropagation();
            removerPagina(index);
            miniaturaWrapper.remove();
            atualizarMiniaturas();
        };
    });
}

