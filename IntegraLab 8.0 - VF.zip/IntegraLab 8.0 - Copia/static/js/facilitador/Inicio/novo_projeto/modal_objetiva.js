import { adicionarElementoCustomizado } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const miniaturasContainer = document.getElementById('miniaturas-widgets');
    const buttonObjetiva = document.querySelector('[data-widget="Button_Objetiva"]');
    buttonObjetiva.addEventListener('click', () => abrirModalObjetiva());
});

function abrirModalObjetiva() {
    const overlay = document.createElement('div');
    overlay.className = 'mini-janela-modal';
    overlay.innerHTML = `
        <div class="mini-janela-conteudo">
            <span class="fechar-mini-janela">✖</span>
            <h3>Criar Pergunta Objetiva</h3>

            <label for="tipo-pergunta">Tipo:</label>
            <select id="tipo-pergunta" style="width: 100%; margin-bottom: 10px;">
                <option value="">Selecione um tipo</option>
                <option value="multipla">Múltipla Escolha</option>
                <option value="vf">Verdadeiro/Falso</option>
                <option value="relacione">Relacione as Colunas</option>
                <option value="likert">Escala Likert</option>
            </select>

            <div id="campos-dinamicos"></div>

            <button id="salvar-pergunta" style="display:none;">Salvar</button>
        </div>
    `;
    document.body.appendChild(overlay);

    const tipoSelect = overlay.querySelector('#tipo-pergunta');
    const camposDinamicos = overlay.querySelector('#campos-dinamicos');
    const salvarBtn = overlay.querySelector('#salvar-pergunta');

    tipoSelect.addEventListener('change', () => {
        const tipo = tipoSelect.value;
        atualizarCamposPorTipo(tipo, camposDinamicos);
        salvarBtn.style.display = 'block';
    });

    overlay.querySelector('.fechar-mini-janela').addEventListener('click', () => overlay.remove());

    salvarBtn.addEventListener('click', () => {
        const tipo = tipoSelect.value;
        const enunciado = camposDinamicos.querySelector('#enunciado')?.value.trim() || '';

        const dadosPergunta = {
            tipo,
            enunciado,
            opcoes: []
        };

        if (tipo === 'multipla' || tipo === 'vf') {
            const linhas = camposDinamicos.querySelectorAll('.linha-opcao');
            linhas.forEach(linha => {
                const texto = linha.querySelector('.texto-opcao')?.value;
                const nota = parseFloat(linha.querySelector('.input-nota')?.value || 0);
                const correta = linha.querySelector('input[type="radio"]')?.checked || false;
                dadosPergunta.opcoes.push({ texto, nota, correta });
            });
        }

        if (tipo === 'relacione') {
            const linhas = camposDinamicos.querySelectorAll('.linha-relacione');
            linhas.forEach((linha, i) => {
                const colA = linha.querySelector('.col-a')?.value;
                const colB = linha.querySelector('.col-b')?.value;
                const nota = parseFloat(linha.querySelector('.input-nota')?.value || 0);
                dadosPergunta.opcoes.push({ id: i, colA, colB, nota });
            });
        }

        if (tipo === 'likert') {
            const linhas = camposDinamicos.querySelectorAll('.linha-likert');
            linhas.forEach(linha => {
                const pergunta = linha.querySelector('.texto-likert')?.value;
                const nota = linha.querySelector('.nota-likert')?.value;
                dadosPergunta.opcoes.push({ pergunta, nota });
            });
        }

        adicionarMiniaturaWidget(dadosPergunta);
        overlay.remove();
    });
}

function atualizarCamposPorTipo(tipo, container) {
    container.innerHTML = '';

    if (tipo === 'multipla' || tipo === 'vf') {
        container.innerHTML += `
            <label>Enunciado:</label>
            <textarea id="enunciado" rows="2" style="width: 100%;"></textarea>
        `;

        const opcoes = tipo === 'multipla'
            ? ['A', 'B', 'C', 'D']
            : ['Verdadeiro', 'Falso'];

        opcoes.forEach((opcao, i) => {
            container.innerHTML += `
                <div class="linha-opcao">
                    <input type="radio" name="correta" ${tipo === 'vf' && i === 0 ? 'checked' : ''}/>
                    <input type="text" class="texto-opcao" value="${opcao}" ${tipo === 'vf'} />
                    <input type="number" class="input-nota" placeholder="Nota" min="0" />
                </div>
            `;
        });
    }

    if (tipo === 'relacione') {
        container.innerHTML += `
            <label>Enunciado:</label>
            <textarea id="enunciado" rows="2" style="width: 100%;"></textarea>
            <div id="relacione-linhas"></div>
            <button id="adicionar-relacione">Adicionar Linha</button>
        `;

        const lista = container.querySelector('#relacione-linhas');
        const btnAdd = container.querySelector('#adicionar-relacione');

        const adicionarLinha = () => {
            const div = document.createElement('div');
            div.classList.add('linha-relacione');
            div.innerHTML = `
                <input class="col-a" placeholder="Coluna A" />
                <input class="col-b" placeholder="Coluna B" />
                <input class="input-nota" placeholder="Nota" type="number" min="0" />
                <button class="remover-linha">🗑️</button>
            `;
            div.querySelector('.remover-linha').onclick = () => div.remove();
            lista.appendChild(div);
        };

        for (let i = 0; i < 2; i++) adicionarLinha();
        btnAdd.onclick = adicionarLinha;
    }

    if (tipo === 'likert') {
        container.innerHTML += `
            <label>Enunciado:</label>
            <textarea id="enunciado" rows="2" style="width: 100%;"></textarea>
            <table border="1" style="width: 100%; text-align: center; margin-top: 10px;">
                <thead>
                    <tr>
                        <th></th>
                        <th>Concordo Totalmente</th>
                        <th>Concordo</th>
                        <th>Neutro</th>
                        <th>Discordo</th>
                        <th>Discordo Totalmente</th>
                    </tr>
                </thead>
                <tbody id="likert-body">
                    <tr class="linha-likert">
                        <td><input class="texto-likert" placeholder="Afirmativa" /></td>
                        <td><input type="radio" name="likert0" value="5" /></td>
                        <td><input type="radio" name="likert0" value="4" /></td>
                        <td><input type="radio" name="likert0" value="3" /></td>
                        <td><input type="radio" name="likert0" value="2" /></td>
                        <td><input type="radio" name="likert0" value="1" /></td>
                    </tr>
                </tbody>
            </table>
            <button id="add-linha-likert">Adicionar Linha</button>
        `;

        let linhaIndex = 1;
        container.querySelector('#add-linha-likert').addEventListener('click', () => {
            const row = document.createElement('tr');
            row.className = 'linha-likert';
            row.innerHTML = `
                <td><input class="texto-likert" placeholder="Afirmativa" /></td>
                <td><input type="radio" name="likert${linhaIndex}" value="5" /></td>
                <td><input type="radio" name="likert${linhaIndex}" value="4" /></td>
                <td><input type="radio" name="likert${linhaIndex}" value="3" /></td>
                <td><input type="radio" name="likert${linhaIndex}" value="2" /></td>
                <td><input type="radio" name="likert${linhaIndex}" value="1" /></td>
            `;
            container.querySelector('#likert-body').appendChild(row);
            linhaIndex++;
        });
    }
}

function obterIconePorTipo(tipo) {
    switch (tipo) {
        case 'multipla':
            return '🔘'; // Múltipla Escolha
        case 'vf':
            return '✅❌'; // Verdadeiro/Falso
        case 'relacione':
            return '🔗'; // Relacione as Colunas
        case 'likert':
            return '📊'; // Escala Likert
        default:
            return '📄'; // Ícone genérico
    }
}

function adicionarMiniaturaWidget(dadosPergunta) {
    const miniaturasContainer = document.getElementById('miniaturas-widgets');

    const wrapper = document.createElement('div');
    wrapper.className = 'botao-widget';
    wrapper.setAttribute('draggable', true);
    wrapper.dataset.widgetData = JSON.stringify(dadosPergunta);

    const icone = obterIconePorTipo(dadosPergunta.tipo);

    wrapper.innerHTML = `
        <span>${icone} ${dadosPergunta.tipo} - Objetiva</span>
        <button class="btn-apagar">🗑️</button>
    `;

    wrapper.querySelector('.btn-apagar').addEventListener('click', () => wrapper.remove());

    wrapper.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', JSON.stringify(dadosPergunta));
        e.dataTransfer.setData('tipo', 'widget');
    });

    wrapper.addEventListener('dblclick', () => {
        adicionarElementoCustomizado('widget', JSON.stringify(dadosPergunta), 100, 100);
    });

    miniaturasContainer.appendChild(wrapper);
}
