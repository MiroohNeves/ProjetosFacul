import { adicionarElementoCustomizado } from './canvas.js';

export function abrirModalLogica() {
    const modal = document.createElement('div');
    modal.className = 'mini-janela-modal';

    const conteudo = document.createElement('div');
    conteudo.className = 'mini-janela-conteudo';

    const fecharBtn = document.createElement('span');
    fecharBtn.className = 'fechar-mini-janela';
    fecharBtn.innerHTML = '&times;';
    fecharBtn.addEventListener('click', () => modal.remove());

    const titulo = document.createElement('h3');
    titulo.textContent = 'Criar Pergunta Lógica (Sequenciamento)';

    const enunciado = document.createElement('textarea');
    enunciado.placeholder = 'Digite o enunciado da pergunta lógica';
    enunciado.style.width = '100%';
    enunciado.style.height = '60px';
    enunciado.style.margin = '10px 0';

    const notaInput = document.createElement('input');
    notaInput.type = 'number';
    notaInput.min = 0;
    notaInput.max = 100;
    notaInput.placeholder = 'Nota (0-100)';
    notaInput.style.width = '100%';

    const btnInserir = document.createElement('button');
    btnInserir.textContent = 'Inserir no Canvas';

    btnInserir.addEventListener('click', () => {
        const texto = enunciado.value.trim();
        const nota = parseInt(notaInput.value);

        if (!texto || isNaN(nota)) {
            alert('Preencha o enunciado e a nota corretamente.');
            return;
        }

        // Pode usar JSON ou string formatada
        const widgetData = `Lógica: ${texto} (Nota: ${nota})`;
        adicionarElementoCustomizado('widget', widgetData);
        modal.remove();
    });

    conteudo.appendChild(fecharBtn);
    conteudo.appendChild(titulo);
    conteudo.appendChild(enunciado);
    conteudo.appendChild(notaInput);
    conteudo.appendChild(btnInserir);
    modal.appendChild(conteudo);
    document.body.appendChild(modal);
}
