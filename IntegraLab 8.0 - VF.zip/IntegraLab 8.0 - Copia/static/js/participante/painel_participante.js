document.addEventListener('DOMContentLoaded', function () {
  const calendarEl = document.getElementById('calendario');

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    locale: 'pt-br',
    height: 'auto',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,dayGridWeek'
    },
    events: [
            {
                title: 'Entrega do Projeto',
                start: '2025-05-25',
                classNames: ['alerta']  // vai aplicar fundo vermelho
            },
            {
                title: 'Reunião Geral',
                start: '2025-05-27',
                classNames: ['info']    // fundo amarelo
            },
            {
                title: 'Workshop Online',
                start: '2025-05-30',
                classNames: []          // padrão azul
            }
    ],
    dayCellDidMount: function (info) {
      const hoje = new Date();
      const data = info.date;
      if (
        data.getDate() === hoje.getDate() &&
        data.getMonth() === hoje.getMonth() &&
        data.getFullYear() === hoje.getFullYear()
      ) {
        info.el.style.border = '2px solid #2ecc71';
        info.el.style.borderRadius = '50%';
      }
    }
  });

  calendar.render();
});
