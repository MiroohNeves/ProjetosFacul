// Função para simular o efeito de digitação
const typewriterEffect = (elementId, text, speed) => {
    let i = 0;
    const element = document.getElementById(elementId);
    element.innerHTML = ""; // Limpa o conteúdo do elemento para começar a digitar

    const typing = () => {
        if (i < text.length) {
            element.innerHTML += text.charAt(i); // Adiciona uma letra por vez
            i++;
            setTimeout(typing, speed); // Chama a função novamente com delay
        }
    };

    typing();
};

// Quando a página carregar, aplica o efeito de digitação
    const texto = "IntegraLab";
    let index = 0;
    const velocidade = 150;
    const elemento = document.getElementById("typewriter-text");

    function escrever() {
        if (index < texto.length) {
            elemento.innerHTML += texto.charAt(index);
            index++;
            setTimeout(escrever, velocidade);
        }
    }

    document.addEventListener("DOMContentLoaded", escrever);